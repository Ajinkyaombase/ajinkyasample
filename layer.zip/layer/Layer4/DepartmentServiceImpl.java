package com.java.Layer4;

import java.util.List;

import com.java.Layer2.Department;
import com.java.Layer3.DepartmentDAOImpl;

public class DepartmentServiceImpl implements DepartmentService {
        
	 
	DepartmentDAOImpl deptDao =new DepartmentDAOImpl();
	
	@Override
	public void createDepartmentService(Department dobj) {
		// TODO Auto-generated method stub
     System.out.println();
    	 deptDao.insertDepartment(dobj);
    	 System.out.println("DepartmentServiceImpl : createDepartment");
     }

	@Override
	public List<Department> findAllDeptsService() {
		// TODO Auto-generated method stub
		return deptDao.selectDepartments();
	}
	}


