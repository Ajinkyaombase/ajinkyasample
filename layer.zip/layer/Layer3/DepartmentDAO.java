package com.java.Layer3;

import java.util.List;

import com.java.Layer2.Department;

public interface DepartmentDAO {
	
	void insertDepartment(Department dobj);  //import from dept
	
	Department selectDepartment(int dno);
	List<Department> selectDepartments();  // import from list
	
	void updateDepartment(Department dobj);
	void deleteDepartment( int dno); //for implements new class departmentimpl 

}
