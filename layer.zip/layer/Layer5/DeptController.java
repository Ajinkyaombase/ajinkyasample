package com.java.Layer5;

import com.java.Layer2.Department;
import com.java.Layer4.DepartmentServiceImpl;

public class DeptController {
 public static void main(String[] args) {
	
	  DepartmentServiceImpl deptService = new DepartmentServiceImpl();
	    
	  Department deptObj = new Department();
	  deptObj.setDepartmentNumber(55);    //this can be from html
	  deptObj.setDepartmentName("Food");  //this can be from html
	  deptObj.setDepartmentLoc("Hotel");   //this can be from html
	    
	   deptService.createDepartmentService(deptObj);
	   
}
}
