package com.java.Layer2;

// for dept table

public class Department {
	
    private int departmentNumber ;   //pojo
    private String departmentName ;  //pojo
    private String departmentLoc ;   //pojo
    
    // getter and setter method
    
	public int getDepartmentNumber() {
		return departmentNumber;
	}
	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getDepartmentLoc() {
		return departmentLoc;
	}
	public void setDepartmentLoc(String departmentLoc) {
		this.departmentLoc = departmentLoc;
	}
    
  
}