package com.java.test;

import com.java.bank.SavingAccount;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class Tester {
    
	@Test
	public void testA() {
		System.out.println("a Testing2 saving account...");
		SavingAccount saObj = Bank.getAccount("sav");
		Assertions.assertTrue(saObj!=null);
		System.out.println("Test passsed");
		
		System.out.println("Object created...");
		saObj.withdraw(4000);
		Assertions.assertEquals(1000,saObj.getAccountBalance());
		System.out.println("Test passed2....");
	}
}
