
public class Fourwheeler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       System.out.println("fourwheelertest loading...");
       
       creta mycreta =new creta();
        mycreta.setColor("white");
        mycreta.setMaxSpeed(220);
        mycreta.fourwheelerinfo();
        mycreta.cretastartdemo();
        mycreta.setdieselcapacity(10);
	}

}
class Engine
{
	public void start()
	{
	  System.out.println("start:");
	}
	public void stop()
	{
	  System.out.println("stop:");
	}

	
}
class Fourwheelers
{
	private String color;
	
	private int maxSpeed;
	
	private int dieselcapacity;
	
	public void fourwheelerinfo()      
	{
		System.out.println("Fourwheeler color="+color+" Maxspeed="+maxSpeed+" dieselcapacity="+dieselcapacity);
	}
	
	public void setColor(String color)  
	{
		this.color=color;
	}
	
	public void setMaxSpeed(int maxSpeed)  //function
	{
		this.maxSpeed=maxSpeed;
	}
	
	public void setdieselcapacity(int dieselcapacity)
	{
		this.dieselcapacity=dieselcapacity;
	}
}


class creta extends Fourwheelers     //is a relship
{
	public void cretastartdemo()
	{
		Engine cretaEngine=new Engine();
		cretaEngine.stop();
		
	}
	
}



